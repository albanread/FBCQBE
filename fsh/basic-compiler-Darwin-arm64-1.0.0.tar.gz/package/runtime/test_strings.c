//
// test_strings.c
// Test program for UTF-32 string implementation
//

#include "string_descriptor.h"
#include <stdio.h>

int main(void) {
    printf("=== UTF-32 String Implementation Test ===\n\n");
    
    // Test 1: Create strings from UTF-8
    printf("Test 1: String creation\n");
    StringDescriptor* s1 = string_new_utf8("Hello");
    StringDescriptor* s2 = string_new_utf8("World");
    printf("  s1 = \"%s\" (length=%lld)\n", string_to_utf8(s1), string_length(s1));
    printf("  s2 = \"%s\" (length=%lld)\n", string_to_utf8(s2), string_length(s2));
    
    // Test 2: Concatenation
    printf("\nTest 2: Concatenation\n");
    StringDescriptor* s3 = string_concat(s1, s2);
    printf("  s1 + s2 = \"%s\"\n", string_to_utf8(s3));
    
    // Test 3: Substring operations
    printf("\nTest 3: Substring operations\n");
    StringDescriptor* left = string_left(s3, 5);
    StringDescriptor* right = string_right(s3, 5);
    StringDescriptor* mid = string_mid(s3, 2, 6);
    printf("  LEFT$(s3, 5) = \"%s\"\n", string_to_utf8(left));
    printf("  RIGHT$(s3, 5) = \"%s\"\n", string_to_utf8(right));
    printf("  MID$(s3, 3, 6) = \"%s\"\n", string_to_utf8(mid));
    
    // Test 4: Character access
    printf("\nTest 4: Character access\n");
    printf("  ASC(s1) = %u ('%c')\n", basic_asc(s1), (char)basic_asc(s1));
    StringDescriptor* chr_a = basic_chr('A');
    printf("  CHR$(65) = \"%s\"\n", string_to_utf8(chr_a));
    
    // Test 5: String comparison
    printf("\nTest 5: String comparison\n");
    StringDescriptor* s4 = string_new_utf8("Hello");
    printf("  s1 == s4: %d\n", string_equals(s1, s4));
    printf("  s1 == s2: %d\n", string_equals(s1, s2));
    printf("  compare(s1, s2): %d\n", string_compare(s1, s2));
    
    // Test 6: Case conversion
    printf("\nTest 6: Case conversion\n");
    StringDescriptor* upper = string_upper(s1);
    StringDescriptor* lower = string_lower(upper);
    printf("  UCASE$(s1) = \"%s\"\n", string_to_utf8(upper));
    printf("  LCASE$(upper) = \"%s\"\n", string_to_utf8(lower));
    
    // Test 7: INSTR function
    printf("\nTest 7: INSTR function\n");
    StringDescriptor* haystack = string_new_utf8("The quick brown fox");
    StringDescriptor* needle1 = string_new_utf8("quick");
    StringDescriptor* needle2 = string_new_utf8("slow");
    int64_t pos1 = string_instr(haystack, needle1, 0);
    int64_t pos2 = string_instr(haystack, needle2, 0);
    printf("  INSTR(\"%s\", \"%s\") = %lld\n", 
           string_to_utf8(haystack), string_to_utf8(needle1), (long long)(pos1 + 1));
    printf("  INSTR(\"%s\", \"%s\") = %lld\n", 
           string_to_utf8(haystack), string_to_utf8(needle2), (long long)(pos2 + 1));
    
    // Test 8: Trim functions
    printf("\nTest 8: Trim functions\n");
    StringDescriptor* padded = string_new_utf8("  Hello World  ");
    StringDescriptor* trimmed = string_trim(padded);
    StringDescriptor* ltrimmed = string_ltrim(padded);
    StringDescriptor* rtrimmed = string_rtrim(padded);
    printf("  Original: \"%s\"\n", string_to_utf8(padded));
    printf("  TRIM$: \"%s\"\n", string_to_utf8(trimmed));
    printf("  LTRIM$: \"%s\"\n", string_to_utf8(ltrimmed));
    printf("  RTRIM$: \"%s\"\n", string_to_utf8(rtrimmed));
    
    // Test 9: Number conversions
    printf("\nTest 9: Number conversions\n");
    StringDescriptor* num_str = string_new_utf8("12345");
    int64_t num_int = string_to_int(num_str);
    StringDescriptor* back_to_str = string_from_int(num_int);
    printf("  VAL(\"%s\") = %lld\n", string_to_utf8(num_str), (long long)num_int);
    printf("  STR$(%lld) = \"%s\"\n", (long long)num_int, string_to_utf8(back_to_str));
    
    // Test 10: SPACE$ and STRING$
    printf("\nTest 10: SPACE$ and STRING$ functions\n");
    StringDescriptor* spaces = basic_space(10);
    StringDescriptor* stars = basic_string_repeat(8, '*');
    printf("  SPACE$(10) = \"%s\" (length=%lld)\n", 
           string_to_utf8(spaces), string_length(spaces));
    printf("  STRING$(8, '*') = \"%s\"\n", string_to_utf8(stars));
    
    // Test 11: Unicode support
    printf("\nTest 11: Unicode support\n");
    StringDescriptor* unicode = string_new_utf8("Hello 世界 🌍");
    printf("  Unicode string: \"%s\"\n", string_to_utf8(unicode));
    printf("  Length in code points: %lld\n", string_length(unicode));
    printf("  First char: U+%04X\n", string_char_at(unicode, 0));
    printf("  Char at 6: U+%04X\n", string_char_at(unicode, 6));
    
    // Test 12: Reference counting
    printf("\nTest 12: Reference counting\n");
    StringDescriptor* s5 = string_new_utf8("Test");
    printf("  Initial refcount: %d\n", s5->refcount);
    StringDescriptor* s6 = string_retain(s5);
    printf("  After retain: %d\n", s5->refcount);
    string_release(s6);
    printf("  After release: %d\n", s5->refcount);
    
    // Cleanup
    string_release(s1);
    string_release(s2);
    string_release(s3);
    string_release(s4);
    string_release(s5);
    string_release(left);
    string_release(right);
    string_release(mid);
    string_release(chr_a);
    string_release(upper);
    string_release(lower);
    string_release(haystack);
    string_release(needle1);
    string_release(needle2);
    string_release(padded);
    string_release(trimmed);
    string_release(ltrimmed);
    string_release(rtrimmed);
    string_release(num_str);
    string_release(back_to_str);
    string_release(spaces);
    string_release(stars);
    string_release(unicode);
    
    printf("\n=== All tests completed successfully! ===\n");
    return 0;
}
